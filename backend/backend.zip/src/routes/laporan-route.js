// src/routes/laporan-route.js
const express = require("express");
const route = express.Router();

// Impor fungsi controller yang benar
const {
  getAllLaporan,
  getLaporan,
  addLaporan,
  deleteLaporan,
  approveAndGeneratePdfReport,
  approveOnly, // Jika masih dipakai
  generateDirectPdfReport,
  adhocDownloadPdfReport,
  downloadPdfByFilename, // Endpoint baru
} = require("../controllers/laporan-controller.js");

// Middleware otentikasi (ASUMSIKAN ANDA PUNYA, contoh nama: verifyAdminToken)
// const { verifyAdminToken } = require('../middleware/authMiddleware'); // Sesuaikan path

route.get("/", getAllLaporan); // Bisa jadi perlu otentikasi admin
route.get("/:id", getLaporan); // Bisa jadi perlu otentikasi admin
route.post("/", addLaporan); // Umumnya publik

// Endpoint di bawah ini idealnya memerlukan otentikasi admin
// Tambahkan middleware otentikasi Anda di sini, contoh: verifyAdminToken
route.put(
  "/:id/approve-generate-pdf",
  /* verifyAdminToken, */ approveAndGeneratePdfReport
);
route.put("/:id/approve", /* verifyAdminToken, */ approveOnly); // Jika masih dipakai
route.post(
  "/generate-direct-pdf",
  /* verifyAdminToken, */ generateDirectPdfReport
);
route.delete("/:id", /* verifyAdminToken, */ deleteLaporan);

// Endpoint untuk mengunduh PDF yang sudah ada (berdasarkan ID Laporan)
// Ini bisa dilindungi jika PDF bersifat rahasia
route.get(
  "/adhoc-download-pdf/:id",
  /* verifyToken (bisa user biasa jika sudah diapprove), */ adhocDownloadPdfReport
);

// Endpoint baru untuk mengunduh PDF berdasarkan nama file (untuk direct PDF)
// Ini juga bisa dilindungi
route.get(
  "/download/reports/:filename",
  /* verifyToken, */ downloadPdfByFilename
);

module.exports = route;
