// src/controllers/laporan-controller.js
const {
  Laporan,
  Kwarran,
  Gudep,
  User, // diasumsikan ada dan digunakan di fungsi render
  PesertaDidik, // diasumsikan ada
  Prestasi, // diasumsikan ada
  Geografis, // diasumsikan ada
  Event, // diasumsikan ada
} = require("../models");
const path = require("path");
const fs = require("fs");
const { Op } = require("sequelize");
require("dotenv").config();
const puppeteer = require("puppeteer");
const StatusCodes = require("http-status-codes");

const PDF_STORAGE_DIR = path.join(process.cwd(), "public", "reports");

// Pastikan direktori penyimpanan ada
if (!fs.existsSync(PDF_STORAGE_DIR)) {
  try {
    fs.mkdirSync(PDF_STORAGE_DIR, { recursive: true });
    console.log(`Direktori penyimpanan PDF dibuat: ${PDF_STORAGE_DIR}`);
  } catch (err) {
    console.error(`Gagal membuat direktori penyimpanan PDF: ${err}`);
    // Pertimbangkan untuk menghentikan aplikasi jika direktori penting ini tidak bisa dibuat
  }
}

// --- Fungsi Puppeteer untuk PDF --- (TETAP SAMA)
async function launchBrowser() {
  console.log("Meluncurkan browser Puppeteer...");
  try {
    const executablePath = process.env.PUPPETEER_EXECUTABLE_PATH || undefined;
    const browser = await puppeteer.launch({
      headless: true,
      executablePath: executablePath,
      args: [
        "--no-sandbox",
        "--disable-setuid-sandbox",
        "--disable-dev-shm-usage",
        "--disable-gpu",
      ],
      timeout: 60000, // Tambahkan timeout global untuk launch
    });
    console.log("Browser Puppeteer berhasil diluncurkan.");
    return browser;
  } catch (error) {
    console.error("⚠️ Error saat meluncurkan Puppeteer:", error);
    throw new Error(
      `Gagal memulai browser untuk generasi PDF: ${error.message}`
    );
  }
}

async function closeBrowser(browser) {
  if (browser) {
    try {
      console.log("Menutup browser Puppeteer...");
      await browser.close();
      console.log("Browser Puppeteer berhasil ditutup.");
    } catch (err) {
      console.error("⚠️ Error saat menutup browser Puppeteer:", err);
    }
  }
}

async function generatePdfBufferFromHtml(
  browser,
  htmlContent,
  pageOrientation = "portrait"
) {
  let page = null;
  console.log("Membuat halaman baru Puppeteer...");
  try {
    if (!htmlContent || htmlContent.trim() === "") {
      throw new Error("Konten HTML untuk PDF kosong.");
    }
    page = await browser.newPage();
    page.setDefaultTimeout(90000); // Timeout untuk operasi halaman

    page.on("console", (message) =>
      console.log(
        `PUPPETEER CONSOLE: ${message.type().toUpperCase()} ${message.text()}`
      )
    );
    page.on("pageerror", (error) =>
      console.error("PUPPETEER PAGE ERROR:", error.message)
    );

    console.log("Mengatur konten halaman Puppeteer...");
    await page.setContent(htmlContent, {
      waitUntil: "networkidle0", // Tunggu hingga tidak ada aktivitas jaringan signifikan
      timeout: 90000,
    });

    console.log("Men-generate buffer PDF...");
    const pdfBuffer = await page.pdf({
      format: "A4",
      printBackground: true,
      margin: { top: "15mm", right: "15mm", bottom: "15mm", left: "15mm" },
      timeout: 90000, // Timeout untuk pembuatan PDF
      preferCSSPageSize: true,
      landscape: pageOrientation === "landscape",
    });

    if (!pdfBuffer || pdfBuffer.length < 100) {
      // Cek ukuran minimal buffer
      throw new Error(
        `Buffer PDF yang dihasilkan tidak valid (ukuran: ${
          pdfBuffer?.length || 0
        } bytes)`
      );
    }
    console.log(`Buffer PDF berhasil di-generate: ${pdfBuffer.length} bytes`);
    return pdfBuffer;
  } catch (error) {
    console.error(
      "⚠️ Error saat men-generate buffer PDF dari HTML:",
      error.message,
      error.stack // Tambahkan stack trace untuk debugging
    );
    throw new Error(`Gagal membuat buffer PDF dari HTML: ${error.message}`);
  } finally {
    if (page)
      await page
        .close()
        .catch((err) => console.error("Error menutup halaman Puppeteer:", err));
  }
}

// --- Fungsi Render HTML (ASUMSIKAN SUDAH ADA DAN BENAR dari kode Anda sebelumnya) ---
// Salin implementasi lengkap renderAllHtml, renderGudepHtml, renderKwarranHtml dari kode Anda sebelumnya ke sini
// Pastikan fungsi-fungsi ini ada dan benar. Saya akan menyalin dari unggahan Anda:
async function renderAllHtml() {
  console.log("Memulai render HTML untuk semua data...");
  try {
    const allKwaran = await Kwarran.findAll({
      include: [
        {
          model: Gudep,
          as: "gudepesList",
          attributes: ["id", "no_gudep"],
          where: { no_gudep: { [Op.ne]: "ADMIN" } },
          required: false,
        },
      ],
      order: [["nama", "ASC"]],
    });
    const allGudep = await Gudep.findAll({
      where: { no_gudep: { [Op.ne]: "ADMIN" } },
      include: [
        { model: User, as: "useres", attributes: ["username"] },
        { model: Geografis, as: "geografises" },
        { model: Kwarran, as: "kwarranes", attributes: ["nama"] },
      ],
      order: [
        [{ model: Kwarran, as: "kwarranes" }, "nama", "ASC"],
        ["no_gudep", "ASC"],
      ],
    });
    const allEvents = await Event.findAll({
      order: [["tanggal_mulai", "DESC"]],
    });
    const templatePath = path.join(
      __dirname,
      "..",
      "views",
      "report-template.html"
    ); // Sesuaikan path ke views
    if (!fs.existsSync(templatePath))
      throw new Error(`Template tidak ditemukan: ${templatePath}`);
    let template = fs.readFileSync(templatePath, "utf-8");
    const currentDate = new Date().toLocaleString("id-ID", {
      dateStyle: "full",
      timeStyle: "long",
      timeZone: "Asia/Makassar", // Sesuaikan dengan dateUtils Anda
    });
    const kwarranRows =
      allKwaran
        .map(
          (k) =>
            `<tr><td>${k?.kode || "-"}</td><td>${k?.nama || "-"}</td><td>${
              k?.ketua_kwarran || "-"
            }</td><td>${k?.ketua_dkr || "-"}</td><td>${
              k?.email || "-"
            }</td><td>${k.gudepesList?.length || 0}</td></tr>`
        )
        .join("") || "<tr><td colspan='6'>Tidak ada data Kwarran.</td></tr>";
    const gudepRows =
      allGudep
        .map(
          (g, index) =>
            `<tr><td>${index + 1}</td><td>${
              g?.kwarranes?.nama || "-"
            }</td><td>${g?.no_gudep || "-"}</td><td>${
              g?.tingkatan || "-"
            }</td><td>${g?.pangkalan || "-"}</td><td>${
              g?.ambalan || "-"
            }</td><td>${g?.mabigus || "-"}</td><td>${
              g?.pembina || "-"
            }</td><td>${g?.pelatih || "-"}</td><td>${g?.email || "-"}</td><td>${
              g?.jumlah_putra || 0
            }</td><td>${g?.jumlah_putri || 0}</td></tr>`
        )
        .join("") || "<tr><td colspan='12'>Tidak ada data Gudep.</td></tr>";
    const geografisRows =
      allGudep
        .filter((g) => g.geografises)
        .map(
          (g, index) =>
            `<tr><td>${index + 1}</td><td>${
              g?.kwarranes?.nama || "-"
            }</td><td>${g?.no_gudep || "-"}</td><td>${
              g.geografises?.titik_koordinat || "-"
            }</td><td>${g.geografises?.alamat || "-"}</td></tr>`
        )
        .join("") || "<tr><td colspan='5'>Tidak ada data geografis.</td></tr>";
    const eventRows =
      allEvents
        .map(
          (e, index) =>
            `<tr><td>${index + 1}</td><td>${e?.nama || "-"}</td><td>${
              e?.tanggal_mulai
                ? new Date(e.tanggal_mulai).toLocaleDateString("id-ID")
                : "-"
            }</td><td>${
              e?.tanggal_selesai
                ? new Date(e.tanggal_selesai).toLocaleDateString("id-ID")
                : "-"
            }</td><td>${e?.tempat || "-"}</td><td>${
              e?.tingkat || "-"
            }</td><td>${e?.penyelenggara || "-"}</td></tr>`
        )
        .join("") || "<tr><td colspan='7'>Tidak ada data kegiatan.</td></tr>";
    template = template
      .replace(/{{{title}}}/g, "Laporan Lengkap Data Pramuka Balikpapan")
      .replace("{{{currentDate}}}", currentDate)
      .replace("{{{kwarranRows}}}", kwarranRows)
      .replace("{{{gudepRows}}}", gudepRows)
      .replace("{{{geografisRows}}}", geografisRows)
      .replace("{{{eventRows}}}", eventRows);
    console.log(`Render HTML semua data selesai. Panjang: ${template.length}`);
    return template;
  } catch (error) {
    console.error(
      "⚠️ Gagal render HTML semua data:",
      error.message,
      error.stack
    );
    throw error;
  }
}

async function renderGudepHtml(gudepId) {
  console.log(`Memulai render HTML untuk Gudep ID: ${gudepId}`);
  try {
    if (!gudepId || typeof gudepId !== "string")
      throw new Error(`ID Gudep tidak valid: ${gudepId}`);
    const gudep = await Gudep.findOne({
      where: { id: gudepId },
      include: [
        { model: User, as: "useres", attributes: ["username"] },
        { model: Geografis, as: "geografises" },
        {
          model: Prestasi,
          as: "prestasies",
          include: [{ model: Event, as: "eventes", attributes: ["nama"] }],
        },
        { model: PesertaDidik, as: "pesertaDidikes", order: [["nama", "ASC"]] },
        { model: Kwarran, as: "kwarranes" },
      ],
    });
    if (!gudep) throw new Error(`Gudep dengan ID ${gudepId} tidak ditemukan.`);
    const templatePath = path.join(
      __dirname, // Asumsi controller ada di src/controllers
      "..", // Mundur ke src
      "views", // Masuk ke views
      "report-template-gudep.html"
    );
    if (!fs.existsSync(templatePath))
      throw new Error(`Template Gudep tidak ditemukan: ${templatePath}`);
    let template = fs.readFileSync(templatePath, "utf-8");
    const currentDate = new Date().toLocaleString("id-ID", {
      // Sesuaikan format tanggal
      dateStyle: "full",
      timeStyle: "long",
      timeZone: "Asia/Makassar",
    });
    const kwarran = gudep.kwarranes || {};
    const geoData = gudep.geografises || {};
    const prestasiRows =
      (gudep.prestasies || [])
        .map(
          (p, index) =>
            `<tr><td>${index + 1}</td><td>${
              p?.eventes?.nama || p?.event_id || "-"
            }</td><td>${p?.keterangan || "-"}</td></tr>`
        )
        .join("") || "<tr><td colspan='3'>Tidak ada data prestasi.</td></tr>";
    const pesertaRows =
      (gudep.pesertaDidikes || [])
        .map(
          (pd, index) =>
            `<tr><td>${index + 1}</td><td>${pd?.nama || "-"}</td><td>${
              pd?.gender || "-"
            }</td><td>${
              pd?.ttl ? new Date(pd.ttl).toLocaleDateString("id-ID") : "-"
            }</td><td>${pd?.detailtingkatan || "-"}</td></tr>`
        )
        .join("") ||
      "<tr><td colspan='5'>Tidak ada data peserta didik.</td></tr>";
    template = template
      .replace(
        /{{{title}}}/g,
        `Laporan Gudep ${gudep.no_gudep || gudep.pangkalan || gudep.id}`
      )
      .replace("{{{currentDate}}}", currentDate)
      .replace("{{{kwarranKode}}}", kwarran?.kode || "-")
      .replace("{{{kwarranNama}}}", kwarran?.nama || "-")
      .replace("{{{kwarranKetua}}}", kwarran?.ketua_kwarran || "-")
      .replace("{{{kwarranKetuaDKR}}}", kwarran?.ketua_dkr || "-")
      .replace("{{{kwarranEmail}}}", kwarran?.email || "-")
      .replace("{{{gudepKode}}}", gudep?.no_gudep || "-")
      .replace("{{{gudepPangkalan}}}", gudep?.pangkalan || "-")
      .replace("{{{gudepTingkatan}}}", gudep?.tingkatan || "-")
      .replace("{{{gudepMabigus}}}", gudep?.mabigus || "-")
      .replace("{{{gudepPembina}}}", gudep?.pembina || "-")
      .replace("{{{gudepPelatih}}}", gudep?.pelatih || "-")
      .replace("{{{gudepEmail}}}", gudep?.email || "-")
      .replace("{{{gudepJumlahLaki}}}", gudep?.jumlah_putra?.toString() || "0")
      .replace(
        "{{{gudepJumlahPerempuan}}}",
        gudep?.jumlah_putri?.toString() || "0"
      )
      .replace("{{{geoKoordinat}}}", geoData?.titik_koordinat || "-")
      .replace("{{{geoLong}}}", geoData?.longitude || "-")
      .replace("{{{geoLat}}}", geoData?.latitude || "-")
      .replace("{{{geoAlamat}}}", geoData?.alamat || "-")
      .replace("{{{prestasiRows}}}", prestasiRows)
      .replace("{{{pesertaRows}}}", pesertaRows);
    console.log(
      `Render HTML Gudep ${gudepId} selesai. Panjang: ${template.length}`
    );
    return template;
  } catch (error) {
    console.error(
      `⚠️ Gagal render HTML Gudep ID ${gudepId}:`,
      error.message,
      error.stack
    );
    throw error;
  }
}

async function renderKwarranHtml(kwarranId) {
  console.log(`Memulai render HTML untuk Kwarran ID: ${kwarranId}`);
  try {
    if (!kwarranId || typeof kwarranId !== "string")
      throw new Error(`ID Kwarran tidak valid: ${kwarranId}`);
    const kwarran = await Kwarran.findOne({
      where: { id: kwarranId },
      include: [
        {
          model: Gudep,
          as: "gudepesList",
          where: { no_gudep: { [Op.ne]: "ADMIN" } },
          required: false,
          include: [{ model: Geografis, as: "geografises" }],
          order: [["no_gudep", "ASC"]],
        },
      ],
    });
    if (!kwarran)
      throw new Error(`Kwarran dengan ID ${kwarranId} tidak ditemukan.`);
    const templatePath = path.join(
      __dirname,
      "..",
      "views",
      "report-template-kwarran.html" // Sesuaikan path
    );
    if (!fs.existsSync(templatePath))
      throw new Error(`Template Kwarran tidak ditemukan: ${templatePath}`);
    let template = fs.readFileSync(templatePath, "utf-8");
    const currentDate = new Date().toLocaleString("id-ID", {
      // Sesuaikan format tanggal
      dateStyle: "full",
      timeStyle: "long",
      timeZone: "Asia/Makassar",
    });
    const gudepRows =
      (kwarran?.gudepesList || [])
        .map(
          (g, index) =>
            `<tr><td>${index + 1}</td><td>${kwarran?.nama || "-"}</td><td>${
              // kwarran.nama untuk kolom kwarran
              g?.no_gudep || "-"
            }</td><td>${g?.tingkatan || "-"}</td><td>${
              g?.pangkalan || "-"
            }</td><td>${g?.ambalan || "-"}</td><td>${
              g?.mabigus || "-"
            }</td><td>${g?.pembina || "-"}</td><td>${
              g?.pelatih || "-"
            }</td><td>${g?.email || "-"}</td><td>${
              g?.jumlah_putra || 0
            }</td><td>${g?.jumlah_putri || 0}</td></tr>`
        )
        .join("") || "<tr><td colspan='12'>Tidak ada data Gudep.</td></tr>"; // colspan disesuaikan
    const geografisRows =
      (kwarran?.gudepesList || [])
        .filter((g) => g.geografises)
        .map(
          (g, index) =>
            `<tr><td>${index + 1}</td><td>${kwarran?.nama || "-"}</td><td>${
              // kwarran.nama untuk kolom kwarran
              g?.no_gudep || "-"
            }</td><td>${g.geografises?.titik_koordinat || "-"}</td><td>${
              g.geografises?.alamat || "-"
            }</td></tr>`
        )
        .join("") ||
      "<tr><td colspan='5'>Tidak ada data geografis Gudep.</td></tr>"; // colspan disesuaikan
    template = template
      .replace(
        /{{{title}}}/g,
        `Laporan Kwarran ${kwarran?.nama || kwarran?.id}`
      )
      .replace("{{{currentDate}}}", currentDate)
      .replace("{{{kwarranKode}}}", kwarran?.kode || "-")
      .replace("{{{kwarranNama}}}", kwarran?.nama || "-")
      .replace("{{{kwarranKetua}}}", kwarran?.ketua_kwarran || "-")
      .replace("{{{kwarranKetuaDKR}}}", kwarran?.ketua_dkr || "-")
      .replace("{{{kwarranEmail}}}", kwarran?.email || "-")
      .replace(
        // Ini sepertinya tidak ada di template Kwarran, tapi jika ada, ini cara mengisinya
        "{{{kwarranJumlahGudep}}}",
        kwarran?.gudepesList?.length.toString() || "0"
      )
      .replace("{{{gudepRows}}}", gudepRows)
      .replace("{{{geografisRows}}}", geografisRows);
    console.log(
      `Render HTML Kwarran ${kwarranId} selesai. Panjang: ${template.length}`
    );
    return template;
  } catch (error) {
    console.error(
      `⚠️ Gagal render HTML Kwarran ID ${kwarranId}:`,
      error.message,
      error.stack
    );
    throw error;
  }
}
// --- End Fungsi Render HTML ---

// Fungsi helper untuk nama file PDF (TETAP SAMA)
const getReportPdfFileName = (level, targetEntity) => {
  const now = new Date();
  const timestamp = `${now.getFullYear()}${String(now.getMonth() + 1).padStart(
    2,
    "0"
  )}${String(now.getDate()).padStart(2, "0")}_${String(now.getHours()).padStart(
    2,
    "0"
  )}${String(now.getMinutes()).padStart(2, "0")}${String(
    now.getSeconds()
  ).padStart(2, "0")}`;
  let baseName = "Laporan_";
  let entityName = "";

  if (level === "semua") {
    entityName = "Semua_Data";
  } else if (targetEntity) {
    if (level === "kwarran") {
      entityName = `Kwarran_${(
        targetEntity.nama || `ID_${targetEntity.id}`
      ).replace(/[^\w.-]+/g, "_")}`;
    } else if (level === "gudep") {
      entityName = `Gudep_${(
        targetEntity.pangkalan ||
        targetEntity.no_gudep ||
        `ID_${targetEntity.id}`
      ).replace(/[^\w.-]+/g, "_")}`;
    }
  } else if (level && !targetEntity) {
    // Untuk kasus direct PDF tanpa nama spesifik dari DB (misal hanya ID)
    entityName = `${level}_Direct_ID`; // Beri penanda
  }
  entityName = entityName.replace(/[^\w.-]+/g, "_"); // Sanitasi tambahan
  baseName += entityName;
  return `${baseName}_${timestamp}.pdf`;
};

// Fungsi helper untuk respon sukses dan error (ASUMSIKAN SUDAH ADA)
const sendSuccess = (res, message, data, statusCode = StatusCodes.OK) => {
  res.status(statusCode).json({ success: true, message, data });
};

const sendError = (
  res,
  message,
  statusCode = StatusCodes.INTERNAL_SERVER_ERROR,
  errorDetails = null
) => {
  console.error(
    "Server Error:",
    message,
    errorDetails ? errorDetails.stack || errorDetails : ""
  );
  res.status(statusCode).json({
    success: false,
    message,
    error: errorDetails ? errorDetails.message || errorDetails : undefined,
  });
};

module.exports = {
  getAllLaporan: async (req, res) => {
    try {
      const allLaporan = await Laporan.findAll({
        order: [["createdAt", "DESC"]],
      });
      sendSuccess(
        res,
        "Data semua permintaan laporan berhasil didapatkan.",
        allLaporan
      );
    } catch (error) {
      sendError(
        res,
        "Gagal mendapatkan data semua permintaan laporan.",
        StatusCodes.INTERNAL_SERVER_ERROR,
        error
      );
    }
  },

  getLaporan: async (req, res) => {
    const { id } = req.params;
    try {
      const laporan = await Laporan.findByPk(id);
      if (!laporan) {
        return sendError(
          res,
          "Data laporan tidak ditemukan.",
          StatusCodes.NOT_FOUND
        );
      }
      sendSuccess(res, "Data laporan berhasil didapatkan.", laporan);
    } catch (error) {
      sendError(
        res,
        "Gagal mendapatkan data laporan.",
        StatusCodes.INTERNAL_SERVER_ERROR,
        error
      );
    }
  },

  addLaporan: async (req, res) => {
    const { nama, asal, noHp, email, level, targetId } = req.body;

    if (!nama || !asal || !noHp || !email || !level) {
      return sendError(
        res,
        "Nama, Asal, No. HP, Email, dan Level wajib diisi.",
        StatusCodes.BAD_REQUEST
      );
    }

    const allowedLevels = Laporan.getAttributes().level.values;
    if (!allowedLevels.includes(level)) {
      return sendError(
        res,
        `Nilai level tidak valid. Pilihan: ${allowedLevels.join(", ")}`,
        StatusCodes.BAD_REQUEST
      );
    }

    if ((level === "kwarran" || level === "gudep") && !targetId) {
      return sendError(
        res,
        `Target ID untuk level '${level}' wajib diisi.`,
        StatusCodes.BAD_REQUEST
      );
    }

    try {
      let finalTargetId = level === "semua" ? null : targetId;
      if (finalTargetId) {
        if (level === "kwarran") {
          const kwarranExists = await Kwarran.findByPk(finalTargetId);
          if (!kwarranExists)
            return sendError(
              res,
              `Kwarran dengan ID ${finalTargetId} tidak ditemukan.`,
              StatusCodes.NOT_FOUND
            );
        }
        if (level === "gudep") {
          const gudepExists = await Gudep.findByPk(finalTargetId);
          if (!gudepExists)
            return sendError(
              res,
              `Gudep dengan ID ${finalTargetId} tidak ditemukan.`,
              StatusCodes.NOT_FOUND
            );
        }
      }

      const newLaporan = await Laporan.create({
        nama,
        asal,
        no_hp: String(noHp),
        email,
        level,
        target_id: finalTargetId,
        status: "Menunggu",
        pdf_path: null,
      });
      sendSuccess(
        res,
        "Permintaan laporan berhasil ditambahkan.",
        newLaporan,
        StatusCodes.CREATED
      );
    } catch (error) {
      if (error.name === "SequelizeValidationError") {
        return sendError(
          res,
          error.errors.map((e) => e.message).join(", "),
          StatusCodes.BAD_REQUEST,
          error
        );
      }
      sendError(
        res,
        "Gagal menambahkan permintaan laporan.",
        StatusCodes.INTERNAL_SERVER_ERROR,
        error
      );
    }
  },

  deleteLaporan: async (req, res) => {
    const { id } = req.params;
    try {
      const laporan = await Laporan.findByPk(id);
      if (!laporan) {
        return sendError(
          res,
          "Laporan tidak ditemukan.",
          StatusCodes.NOT_FOUND
        );
      }

      // Hapus file PDF lokal jika ada
      if (laporan.pdf_path && !laporan.pdf_path.startsWith("http")) {
        // Hanya hapus jika path lokal
        // Asumsi pdf_path adalah path relatif dari 'public', misal '/reports/namafile.pdf'
        const actualFilePath = path.join(
          process.cwd(),
          "public",
          laporan.pdf_path
        );
        if (fs.existsSync(actualFilePath)) {
          try {
            fs.unlinkSync(actualFilePath);
            console.log(`File PDF lokal ${actualFilePath} berhasil dihapus.`);
          } catch (unlinkErr) {
            console.error(
              `Gagal menghapus file PDF lokal ${actualFilePath}:`,
              unlinkErr
            );
            // Pertimbangkan apakah error ini harus menghentikan proses atau hanya dicatat
          }
        } else {
          console.warn(
            `File PDF lokal ${actualFilePath} tidak ditemukan saat mencoba menghapus.`
          );
        }
      }

      await laporan.destroy();
      sendSuccess(res, "Laporan berhasil dihapus.");
    } catch (error) {
      sendError(
        res,
        "Gagal menghapus laporan.",
        StatusCodes.INTERNAL_SERVER_ERROR,
        error
      );
    }
  },

  // Implementasi approveOnly jika masih diperlukan (misal, untuk alur 2 tahap approval)
  approveOnly: async (req, res) => {
    const { id } = req.params;
    const { status } = req.body; // Misal, frontend mengirim status baru

    if (!status || status !== "Setujui") {
      // Hanya izinkan update ke "Setujui" melalui endpoint ini
      return sendError(
        res,
        "Status tidak valid untuk operasi ini.",
        StatusCodes.BAD_REQUEST
      );
    }

    try {
      const laporan = await Laporan.findByPk(id);
      if (!laporan) {
        return sendError(
          res,
          "Permintaan laporan tidak ditemukan.",
          StatusCodes.NOT_FOUND
        );
      }

      // Hanya izinkan perubahan dari "Menunggu" ke "Setujui"
      if (laporan.status !== "Menunggu") {
        return sendError(
          res,
          `Laporan dengan status '${laporan.status}' tidak dapat diubah statusnya menjadi 'Setujui' melalui endpoint ini.`,
          StatusCodes.BAD_REQUEST
        );
      }

      laporan.status = status;
      await laporan.save();
      sendSuccess(res, "Status laporan berhasil diperbarui.", laporan);
    } catch (error) {
      sendError(
        res,
        "Gagal memperbarui status laporan.",
        StatusCodes.INTERNAL_SERVER_ERROR,
        error
      );
    }
  },

  approveAndGeneratePdfReport: async (req, res) => {
    const { id: laporanId } = req.params;
    let laporan;
    let browser = null;

    try {
      console.log(
        `⚡ Memicu Approve & Generate PDF untuk ID Laporan: ${laporanId} (Simpan Lokal)`
      );
      laporan = await Laporan.findByPk(laporanId);
      if (!laporan) {
        return sendError(
          res,
          "Permintaan laporan tidak ditemukan.",
          StatusCodes.NOT_FOUND
        );
      }

      if (!["Menunggu", "Error Generate", "Setujui"].includes(laporan.status)) {
        return sendError(
          res,
          `Laporan status '${laporan.status}' tidak bisa diproses ulang jika sudah Selesai atau status lain yang tidak sesuai.`,
          StatusCodes.BAD_REQUEST
        );
      }

      // Jika statusnya "Menunggu" atau "Error Generate", ubah dulu ke "Setujui"
      if (
        laporan.status === "Menunggu" ||
        laporan.status === "Error Generate"
      ) {
        await laporan.update({ status: "Setujui" });
      }
      // Jika sudah "Setujui", tidak perlu update status lagi di sini sebelum generate

      browser = await launchBrowser();

      let htmlContent = "",
        targetEntity = null,
        pageOrientation = "portrait";

      if (laporan.level === "semua") {
        htmlContent = await renderAllHtml();
        pageOrientation = "landscape";
      } else if (laporan.level === "kwarran") {
        targetEntity = await Kwarran.findByPk(laporan.target_id);
        if (!targetEntity)
          throw new Error(
            `Data Kwarran target (ID: ${laporan.target_id}) tidak ditemukan.`
          );
        htmlContent = await renderKwarranHtml(laporan.target_id);
      } else if (laporan.level === "gudep") {
        targetEntity = await Gudep.findByPk(laporan.target_id);
        if (!targetEntity)
          throw new Error(
            `Data Gudep target (ID: ${laporan.target_id}) tidak ditemukan.`
          );
        htmlContent = await renderGudepHtml(laporan.target_id);
      } else {
        throw new Error(`Level laporan tidak valid: ${laporan.level}`);
      }

      if (!htmlContent?.trim())
        throw new Error("Gagal menghasilkan konten HTML untuk PDF.");

      const pdfBuffer = await generatePdfBufferFromHtml(
        browser,
        htmlContent,
        pageOrientation
      );
      const pdfFileName = getReportPdfFileName(laporan.level, targetEntity);
      const localFilePath = path.join(PDF_STORAGE_DIR, pdfFileName);
      const publicPdfPath = `/reports/${pdfFileName}`; // Path relatif dari 'public'

      fs.writeFileSync(localFilePath, pdfBuffer);
      console.log(`File PDF berhasil disimpan di server: ${localFilePath}`);

      await laporan.update({
        status: "Selesai",
        pdf_path: publicPdfPath,
      });

      const downloadUrl = `/api/laporan/adhoc-download-pdf/${laporan.id}`; // Ini URL yang dikirim

      sendSuccess(res, "Laporan PDF berhasil dibuat dan disimpan di server.", {
        // Ini pesan yang jadi error
        filePath: publicPdfPath,
        downloadUrl: downloadUrl,
        data: laporan, // Mengirimkan data Laporan yang sudah diupdate
      });
    } catch (error) {
      console.error(
        `❌ Gagal proses laporan PDF ID ${laporanId} (simpan lokal):`,
        error.message,
        error.stack
      );
      if (laporan && laporan.status !== "Selesai") {
        // Hindari mengupdate status jika sudah Selesai tapi error di langkah lain
        await laporan
          .update({ status: "Error Generate", pdf_path: null })
          .catch((e) => console.error("Gagal update status error:", e));
      }
      // Jangan mengirim error jika header sudah terkirim (misal oleh sendSuccess di atas)
      if (!res.headersSent) {
        sendError(
          res,
          `Gagal memproses permintaan: ${error.message}`,
          StatusCodes.INTERNAL_SERVER_ERROR,
          error
        );
      }
    } finally {
      if (browser) await closeBrowser(browser);
    }
  },

  generateDirectPdfReport: async (req, res) => {
    const { level, targetId, namaKwarran, namaGudep } = req.body; // namaKwarran & namaGudep digunakan untuk nama file
    let browser = null;

    try {
      console.log(
        `Backend menerima (direct PDF report, simpan lokal): level = ${level}, targetId = ${targetId}`
      );
      if (!level || !["semua", "kwarran", "gudep"].includes(level)) {
        return sendError(
          res,
          "Level laporan tidak valid.",
          StatusCodes.BAD_REQUEST
        );
      }
      if ((level === "kwarran" || level === "gudep") && !targetId) {
        return sendError(
          res,
          `Target ID (${level}) wajib diisi.`,
          StatusCodes.BAD_REQUEST
        );
      }

      browser = await launchBrowser();
      let htmlContent = "",
        targetEntityForFilename = null, // Untuk nama file, bisa dari request body jika ada
        targetEntityForRender = null, // Untuk render HTML, harus dari DB
        pageOrientation = "portrait";

      if (level === "semua") {
        htmlContent = await renderAllHtml();
        pageOrientation = "landscape";
        targetEntityForFilename = null; // Tidak ada entitas spesifik untuk 'semua'
      } else if (level === "kwarran") {
        targetEntityForRender = await Kwarran.findByPk(targetId);
        if (!targetEntityForRender)
          throw new Error(`Target Kwarran (ID: ${targetId}) tidak ditemukan.`);
        htmlContent = await renderKwarranHtml(targetId);
        targetEntityForFilename = {
          id: targetId,
          nama: namaKwarran || targetEntityForRender.nama,
        };
      } else if (level === "gudep") {
        targetEntityForRender = await Gudep.findByPk(targetId);
        if (!targetEntityForRender)
          throw new Error(`Target Gudep (ID: ${targetId}) tidak ditemukan.`);
        htmlContent = await renderGudepHtml(targetId);
        targetEntityForFilename = {
          id: targetId,
          pangkalan: namaGudep || targetEntityForRender.pangkalan,
          no_gudep: targetEntityForRender.no_gudep,
        };
      }

      if (!htmlContent?.trim())
        throw new Error("Konten HTML kosong untuk PDF.");
      const pdfBuffer = await generatePdfBufferFromHtml(
        browser,
        htmlContent,
        pageOrientation
      );

      const pdfFileName = getReportPdfFileName(level, targetEntityForFilename);
      const localFilePath = path.join(PDF_STORAGE_DIR, pdfFileName);
      const publicPdfPath = `/reports/${pdfFileName}`;

      fs.writeFileSync(localFilePath, pdfBuffer);
      console.log(
        `File PDF (direct) berhasil disimpan di server: ${localFilePath}`
      );

      const downloadUrl = `/api/laporan/download${publicPdfPath}`; // Mengarah ke endpoint baru (lihat di laporan-route.js)

      sendSuccess(
        res,
        "Laporan PDF berhasil dibuat dan disimpan di server (Direct).",
        {
          filePathInServer: publicPdfPath,
          downloadUrl: downloadUrl,
        }
      );
    } catch (error) {
      console.error(
        `❌ Gagal generate direct laporan PDF (simpan lokal):`,
        error.message,
        error.stack
      );
      if (!res.headersSent) {
        sendError(
          res,
          `Gagal memproses permintaan direct: ${error.message}`,
          StatusCodes.INTERNAL_SERVER_ERROR,
          error
        );
      }
    } finally {
      if (browser) await closeBrowser(browser);
    }
  },

  adhocDownloadPdfReport: async (req, res) => {
    const { id: laporanId } = req.params;
    try {
      const laporan = await Laporan.findByPk(laporanId);
      if (!laporan || !laporan.pdf_path) {
        return sendError(
          res,
          "Laporan atau path file PDF tidak ditemukan.",
          StatusCodes.NOT_FOUND
        );
      }

      // Pastikan pdf_path bukan URL eksternal lagi
      if (laporan.pdf_path.startsWith("http")) {
        console.warn(
          `pdf_path untuk laporan ${laporanId} masih berupa URL: ${laporan.pdf_path}. Seharusnya path lokal.`
        );
        return sendError(
          res,
          "Format path laporan tidak valid (seharusnya path lokal). Generate ulang laporan.",
          StatusCodes.BAD_REQUEST
        );
      }

      // pdf_path adalah path relatif dari 'public', misal '/reports/namafile.pdf'
      const actualFilePath = path.join(
        process.cwd(),
        "public",
        laporan.pdf_path
      );

      if (fs.existsSync(actualFilePath)) {
        // Ambil nama file asli dari path untuk suggestion di browser
        const fileNameForDownload = path.basename(actualFilePath);
        res.setHeader(
          "Content-Disposition",
          `attachment; filename="${fileNameForDownload}"`
        );
        res.contentType("application/pdf");
        return res.sendFile(actualFilePath, (err) => {
          if (err) {
            console.error(`Error mengirim file ${actualFilePath}:`, err);
            if (!res.headersSent) {
              // Cek apakah header sudah terkirim
              sendError(
                res,
                "Gagal mengirim file PDF.",
                StatusCodes.INTERNAL_SERVER_ERROR,
                err
              );
            } else {
              // Jika header sudah terkirim, error mungkin terjadi saat streaming.
              // Browser klien mungkin sudah menerima sebagian file atau koneksi terputus.
              // Tidak banyak yang bisa dilakukan di sini selain log.
              console.error(
                `Error setelah header terkirim untuk file ${actualFilePath}`
              );
            }
          } else {
            console.log(`File PDF ${actualFilePath} berhasil dikirim.`);
          }
        });
      } else {
        console.warn(
          `File PDF lokal tidak ditemukan di path: ${actualFilePath} untuk laporan ID ${laporanId}`
        );
        return sendError(
          res,
          "File PDF tidak ditemukan di server.",
          StatusCodes.NOT_FOUND
        );
      }
    } catch (error) {
      console.error(
        `❌ Gagal adhoc download PDF dari server (ID: ${laporanId}):`,
        error.message,
        error.stack
      );
      if (!res.headersSent) {
        sendError(
          res,
          `Gagal mengambil file PDF dari server: ${error.message}`,
          StatusCodes.INTERNAL_SERVER_ERROR,
          error
        );
      }
    }
  },

  // Endpoint baru untuk mengunduh PDF berdasarkan nama file (digunakan oleh generateDirectPdfReport)
  downloadPdfByFilename: async (req, res) => {
    const { filename } = req.params;
    // PENTING: Sanitasi filename untuk mencegah directory traversal
    const sanitizedFilename = path.basename(filename);
    if (sanitizedFilename !== filename) {
      return sendError(res, "Nama file tidak valid.", StatusCodes.BAD_REQUEST);
    }

    const filePath = path.join(PDF_STORAGE_DIR, sanitizedFilename);

    if (fs.existsSync(filePath)) {
      res.setHeader(
        "Content-Disposition",
        `attachment; filename="${sanitizedFilename}"`
      );
      res.contentType("application/pdf");
      return res.sendFile(filePath, (err) => {
        if (err) {
          console.error(`Error mengirim file by filename ${filePath}:`, err);
          if (!res.headersSent) {
            sendError(
              res,
              "Gagal mengirim file PDF.",
              StatusCodes.INTERNAL_SERVER_ERROR,
              err
            );
          }
        } else {
          console.log(`File PDF by filename ${filePath} berhasil dikirim.`);
        }
      });
    } else {
      console.warn(`File PDF by filename tidak ditemukan di path: ${filePath}`);
      return sendError(res, "File PDF tidak ditemukan.", StatusCodes.NOT_FOUND);
    }
  },
};
