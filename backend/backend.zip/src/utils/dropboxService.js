// src/utils/dropboxService.js
const { Dropbox, files } = require("dropbox");
require("dotenv").config();
const path = require("path");

const dropboxToken = process.env.DROPBOX_ACCESS_TOKEN;
const appFolderName =
  process.env.DROPBOX_APP_PDF_FOLDER_NAME || "LaporanGeogudep_PDF"; // Folder untuk PDF

if (!dropboxToken) {
  console.error(
    "❌ DROPBOX_ACCESS_TOKEN tidak ditemukan di .env. Upload ke Dropbox akan gagal."
  );
}
const dbx = dropboxToken ? new Dropbox({ accessToken: dropboxToken }) : null;

async function uploadFileToDropbox(fileContents, fileNameInDropbox) {
  if (!dbx) {
    throw new Error(
      "Konfigurasi Dropbox tidak lengkap (token tidak ada). Upload dibatalkan."
    );
  }
  const dropboxPath = (
    "/" + path.join(appFolderName, fileNameInDropbox)
  ).replace(/\\/g, "/");

  try {
    console.log(`Mengunggah file PDF ke Dropbox path: ${dropboxPath}`);
    const response = await dbx.filesUpload({
      path: dropboxPath,
      contents: fileContents, // Ini akan menjadi Buffer PDF
      mode: { ".tag": "overwrite" },
      autorename: false,
      mute: true,
    });
    const uploadedFile = response.result;
    console.log(
      `File PDF berhasil diunggah ke Dropbox: ${uploadedFile.path_display}`
    );

    let sharedLinkUrl = "";
    try {
      const linkSettings = {
        path: uploadedFile.path_lower,
        settings: { requested_visibility: { ".tag": "public" } },
      };
      let linksResponse = await dbx.sharingListSharedLinks({
        path: uploadedFile.path_lower,
        direct_only: true,
      });
      if (linksResponse.result.links && linksResponse.result.links.length > 0) {
        sharedLinkUrl = linksResponse.result.links[0].url;
      } else {
        const sharedLinkCreateResponse =
          await dbx.sharingCreateSharedLinkWithSettings(linkSettings);
        sharedLinkUrl = sharedLinkCreateResponse.result.url;
      }
      console.log(`Link berbagi Dropbox: ${sharedLinkUrl}`);
    } catch (linkError) {
      if (
        linkError.error &&
        typeof linkError.error === "object" &&
        linkError.error.error_summary &&
        linkError.error.error_summary.startsWith("shared_link_already_exists")
      ) {
        try {
          let links = await dbx.sharingListSharedLinks({
            path: uploadedFile.path_lower,
          });
          if (links.result.links && links.result.links.length > 0) {
            sharedLinkUrl = links.result.links[0].url;
          } else {
            throw linkError;
          }
        } catch (listLinkError) {
          console.warn(
            `Gagal membuat/mendapatkan shared link Dropbox untuk ${uploadedFile.path_display} setelah 'already_exists': ${listLinkError.message}. Menggunakan path Dropbox.`
          );
          sharedLinkUrl = `https://www.dropbox.com/home/${appFolderName}${
            uploadedFile.path_display.startsWith("/")
              ? uploadedFile.path_display
              : "/" + uploadedFile.path_display
          }`;
        }
      } else {
        console.warn(
          `Gagal membuat shared link Dropbox untuk ${uploadedFile.path_display}: ${linkError.message}. Menggunakan path Dropbox.`
        );
        sharedLinkUrl = `https://www.dropbox.com/home/${appFolderName}${
          uploadedFile.path_display.startsWith("/")
            ? uploadedFile.path_display
            : "/" + uploadedFile.path_display
        }`;
      }
    }

    let directLink = sharedLinkUrl.replace(
      "www.dropbox.com",
      "dl.dropboxusercontent.com"
    );
    directLink = directLink.replace("?dl=0", "");
    if (!directLink.endsWith("?dl=1") && !directLink.includes("?dl=1&")) {
      directLink = directLink.includes("?")
        ? `${directLink}&dl=1`
        : `${directLink}?dl=1`;
    }
    console.log(`Direct download link Dropbox PDF: ${directLink}`);

    return {
      path_display: uploadedFile.path_display,
      shareable_link: sharedLinkUrl,
      direct_download_link: directLink,
    };
  } catch (error) {
    const errorMessage =
      error.error?.error_summary ||
      error.message ||
      "Unknown Dropbox upload error";
    console.error(
      "Error uploading file to Dropbox:",
      errorMessage,
      error.stack
    );
    throw new Error(`Gagal mengunggah file ke Dropbox: ${errorMessage}`);
  }
}

async function deleteFileFromDropbox(filePathInDropbox) {
  if (!dbx) {
    console.warn(
      "Dropbox SDK tidak terinisialisasi, penghapusan file dilewati."
    );
    return { success: false, message: "Dropbox SDK tidak terinisialisasi." };
  }
  if (
    !filePathInDropbox ||
    !filePathInDropbox.startsWith("/" + appFolderName)
  ) {
    console.error(
      `Path file Dropbox tidak valid untuk penghapusan: ${filePathInDropbox}. Harus dimulai dengan '/${appFolderName}/'.`
    );
    return {
      success: false,
      message: "Path file Dropbox tidak valid untuk penghapusan.",
    };
  }

  try {
    console.log(`Menghapus file dari Dropbox: ${filePathInDropbox}`);
    await dbx.filesDeleteV2({ path: filePathInDropbox });
    console.log(`File ${filePathInDropbox} berhasil dihapus dari Dropbox.`);
    return { success: true, message: "File berhasil dihapus dari Dropbox." };
  } catch (error) {
    const errorSummary = error.error?.error_summary || "";
    if (
      error.status === 409 &&
      errorSummary.startsWith("path_lookup/not_found")
    ) {
      console.warn(
        `File ${filePathInDropbox} tidak ditemukan di Dropbox saat mencoba menghapus.`
      );
      return {
        success: true,
        message: "File tidak ditemukan di Dropbox (mungkin sudah dihapus).",
      };
    }
    console.error(
      `Error menghapus file ${filePathInDropbox} dari Dropbox:`,
      errorSummary || error.message
    );
    return {
      success: false,
      message: `Gagal menghapus file dari Dropbox: ${
        errorSummary || error.message
      }`,
    };
  }
}

module.exports = { uploadFileToDropbox, deleteFileFromDropbox };
